/*document.addEventListener("DOMContentLoaded", function() {
    const cardContent = document.getElementById("card-content");

    // Verifique si el elemento existe antes de aplicar la clase
    if (cardContent) {
        setTimeout(() => {
            cardContent.classList.remove("opacity-0", "translate-y-5");
            cardContent.classList.add("opacity-100", "translate-y-0");
        }, 200); // Retraso de 200ms para que se note la animación
    }
});*/

const card = document.getElementById("card");

const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            card.classList.remove("rotate-y-180");
            card.classList.add("rotate-y-0");
        }
    });
}, { threshold: 0.5 });

observer.observe(card);
